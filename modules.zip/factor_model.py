# factor_model.py
import streamlit as st
import pandas as pd
import yfinance as yf
import statsmodels.api as sm
import matplotlib.pyplot as plt

def run():
    st.title("📊 ファクターモデル分析（Fama-French 3ファクター）")
    ticker = st.text_input("銘柄ティッカー（例：AAPL）", value="AAPL")
    start = st.date_input("開始日", pd.to_datetime("2020-01-01"))
    end = st.date_input("終了日", pd.to_datetime("2023-12-31"))
    if st.button("回帰分析を実行"):
        df_stock = yf.download(ticker, start=start, end=end)["Adj Close"].pct_change().dropna()
        df_stock.name = "Stock"
        try:
            ff_factors = pd.read_csv("fama_french_factors.csv", index_col=0, parse_dates=True)
            df = pd.concat([df_stock, ff_factors], axis=1).dropna()
            X = df[["Mkt-RF", "SMB", "HML"]]
            y = df["Stock"] - df["RF"]
            X = sm.add_constant(X)
            model = sm.OLS(y, X).fit()
            st.markdown("### 回帰結果サマリー")
            st.text(model.summary())
            st.markdown("### 回帰残差のプロット")
            fig, ax = plt.subplots()
            ax.plot(model.resid)
            ax.set_title("残差プロット")
            st.pyplot(fig)
        except Exception as e:
            st.error(f"ファクターデータの読み込みに失敗しました。'fama_french_factors.csv' が必要です。\n{e}")
