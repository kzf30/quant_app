# news_analysis.py
import streamlit as st
import feedparser
from collections import Counter
import re
import pandas as pd

def extract_keywords(text, top_n=10):
    words = re.findall(r"[\u4E00-\u9FFF]+", text)
    counter = Counter(words)
    return counter.most_common(top_n)

def run():
    st.title("📰 ニューストピック分析")
    st.markdown("日経・ロイターなどのRSSフィードから最新ニュースを取得し、頻出キーワードを抽出します。")
    source = st.selectbox("ニュースソースを選択", [
        ("Nikkei 経済", "https://www.nikkei.com/rss/genre/economy.xml"),
        ("Reuters JP Top News", "https://jp.reuters.com/rssFeed/topNews"),
        ("ロイター 経済", "https://jp.reuters.com/rssFeed/businessNews")
    ])
    feed = feedparser.parse(source[1])
    st.markdown(f"### {source[0]} 最新ニュース見出し（上位10件）")
    for entry in feed.entries[:10]:
        st.write(f"- [{entry['title']}]({entry['link']})")
    all_text = " ".join([entry['title'] + entry.get('summary', '') for entry in feed.entries])
    keywords = extract_keywords(all_text, top_n=15)
    df_keywords = pd.DataFrame(keywords, columns=["キーワード", "出現数"])
    st.markdown("### 頻出キーワード（トピック）")
    st.dataframe(df_keywords)
    st.bar_chart(df_keywords.set_index("キーワード"))
