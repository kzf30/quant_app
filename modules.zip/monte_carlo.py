# monte_carlo.py
import streamlit as st
import numpy as np
import matplotlib.pyplot as plt

def simulate_paths(S0, mu, sigma, T, n_steps, n_sims):
    dt = T / n_steps
    paths = np.zeros((n_sims, n_steps + 1))
    paths[:, 0] = S0
    for t in range(1, n_steps + 1):
        z = np.random.standard_normal(n_sims)
        paths[:, t] = paths[:, t - 1] * np.exp((mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * z)
    return paths

def run():
    st.title("🎲 モンテカルロ法による株価シミュレーション")
    S0 = st.number_input("初期株価 S0", value=100.0)
    mu = st.number_input("期待リターン μ (年率)", value=0.05)
    sigma = st.number_input("ボラティリティ σ (年率)", value=0.2)
    T = st.number_input("期間 T (年)", value=1.0)
    n_steps = st.number_input("ステップ数", value=252, step=1)
    n_sims = st.number_input("シミュレーション本数", value=1000, step=100)
    if st.button("シミュレーション実行"):
        paths = simulate_paths(S0, mu, sigma, T, int(n_steps), int(n_sims))
        st.markdown("### 終値の分布（ヒストグラム）")
        fig1, ax1 = plt.subplots()
        ax1.hist(paths[:, -1], bins=50, color="skyblue", edgecolor="black")
        ax1.set_xlabel("終値")
        ax1.set_ylabel("頻度")
        st.pyplot(fig1)
        st.markdown("### ランダムな価格経路の例")
        fig2, ax2 = plt.subplots()
        for i in range(min(30, int(n_sims))):
            ax2.plot(paths[i], linewidth=0.8, alpha=0.6)
        ax2.set_xlabel("ステップ")
        ax2.set_ylabel("株価")
        st.pyplot(fig2)
        st.success("シミュレーションが完了しました！")
