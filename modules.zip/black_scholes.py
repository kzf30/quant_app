# black_scholes.py
import streamlit as st
import numpy as np
from scipy.stats import norm

def black_scholes_price(S, K, T, r, sigma, option_type="call"):
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    if option_type == "call":
        price = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    else:
        price = K * np.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)
    return price, d1, d2

def greeks(S, K, T, r, sigma, option_type="call"):
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)
    delta = norm.cdf(d1) if option_type == "call" else -norm.cdf(-d1)
    gamma = norm.pdf(d1) / (S * sigma * np.sqrt(T))
    vega = S * norm.pdf(d1) * np.sqrt(T) / 100
    theta = (-S * norm.pdf(d1) * sigma / (2 * np.sqrt(T)) - r * K * np.exp(-r * T) * norm.cdf(d2 if option_type == "call" else -d2)) / 365
    rho = (K * T * np.exp(-r * T) * norm.cdf(d2) / 100 if option_type == "call" else -K * T * np.exp(-r * T) * norm.cdf(-d2) / 100)
    return delta, gamma, vega, theta, rho

def run():
    st.title("📘 ブラック＝ショールズ オプション理論価格とグリークス")
    S = st.number_input("現物価格 S", value=100.0)
    K = st.number_input("権利行使価格 K", value=100.0)
    T = st.number_input("満期までの期間 T (年)", value=1.0)
    r = st.number_input("無リスク金利 r (年率)", value=0.01)
    sigma = st.number_input("ボラティリティ σ (年率)", value=0.2)
    option_type = st.selectbox("オプションの種類", ["call", "put"])
    if st.button("計算する"):
        price, d1, d2 = black_scholes_price(S, K, T, r, sigma, option_type)
        delta, gamma, vega, theta, rho = greeks(S, K, T, r, sigma, option_type)
        st.markdown(f"### 理論価格: {price:.3f} ({option_type.upper()})")
        st.markdown("---")
        st.markdown("### グリークス")
        st.write(f"Δ（デルタ）: {delta:.3f}")
        st.write(f"Γ（ガンマ）: {gamma:.3f}")
        st.write(f"ν（ベガ）: {vega:.3f}")
        st.write(f"Θ（セータ）: {theta:.3f}")
        st.write(f"ρ（ロー）: {rho:.3f}")
